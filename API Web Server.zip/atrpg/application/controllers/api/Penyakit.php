<?php
    use Restserver\Libraries\REST_Controller;
    defined('BASEPATH') OR exit('No direct script access allowed');

    require APPPATH . 'libraries/REST_Controller.php';
    require APPPATH . 'libraries/Format.php';

    class Penyakit extends REST_Controller {
        function __construct()
        {
            parent::__construct();
            $this->load->model('Penyakit_model', 'atr');
        }

        // Get Data
        public function index_get() {
            $Antrian = $this->atr->getPenyakit();
            if($Antrian) {
                $this->response(
                    $Antrian
                   , REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'Data not found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }
        public function index_post() {
                $nama_penyakit = $this->post('nama_penyakit');
                $result = $this->atr->getPenyakit($nama_penyakit);
            if ($result) {
                $this->response(
                    $result
                   , REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'Data not found'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        }

    }

?>