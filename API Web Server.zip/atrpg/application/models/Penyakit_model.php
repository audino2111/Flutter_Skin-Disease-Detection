<?php
    class Penyakit_model extends CI_model {
        public function getPenyakit($nama = null) {
            if (!empty($nama)) {
                $sql="select * from tb_penyakit where nama_penyakit = '$nama' limit 1";
            }else {
                $sql="select * from tb_penyakit";
            }               
                $query = $this->db->query($sql);
                return $query->result();
        }
        
        
    }
?>